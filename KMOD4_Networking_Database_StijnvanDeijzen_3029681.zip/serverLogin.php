<?php
include 'connect_mysql.php';
session_start();


$server_name = filter_var($_GET['server_name'], FILTER_SANITIZE_STRING);
$password = filter_var($_GET['password'], FILTER_SANITIZE_STRING);

$query = "SELECT id FROM Servers "
."WHERE server_name = '".$server_name."' "
."AND password = '".$password."' "
."LIMIT 1";

if (!($result = $mysqli->query($query))){
	showerror($mysqli->errno,$mysqli->error);
}else {
	$row = $result->fetch_assoc();
	if($row['id']==null){
		echo "Incorrect Login Info";		
	}else{
		echo session_id();

		$_SESSION["server_id"] = $row['id'];
	}	
}
?>