<?php
include 'connect_mysql.php';

if (isset($_GET['PHPSESSID'])) {
	$sid=filter_var($_GET['PHPSESSID'], FILTER_SANITIZE_STRING);
	session_id($sid);
}
session_start();

if(isset($_SESSION["server_id"]) && $_SESSION["server_id"] != 0)
{

	//getting most first places
	$query = "SELECT p.username,COUNT(first_place) as First FROM Scores s LEFT JOIN Players p ON (s.first_place = p.id) GROUP BY first_place ORDER BY First DESC LIMIT 5";

	if (!($result = $mysqli->query($query)))
	showerror($mysqli->errno,$mysqli->error);
	
	$row = $result->fetch_assoc();
	$topWinners = array();
	do {
		array_push($topWinners , $row);
	} while ($row = $result->fetch_assoc());




	//getting most second places
	$query = "SELECT p.username,COUNT(second_place) as 'Second' FROM Scores s LEFT JOIN Players p ON (s.second_place = p.id) GROUP BY 'Second' ORDER BY 'Second'DESC LIMIT 5";

	if (!($result = $mysqli->query($query)))
	showerror($mysqli->errno,$mysqli->error);
	
	$row = $result->fetch_assoc();
	$topSecond = array();
	do {
		array_push($topSecond , $row);
	} while ($row = $result->fetch_assoc());


	//getting plays
	$query = "SELECT COUNT(*) as Plays FROM Scores WHERE datetime > " 
	. strftime("'%Y/%m/%e'" ,mktime(0, 0, 0, date("m")-1, date("d"), date("Y")));

	if (!($result = $mysqli->query($query))){
		showerror($mysqli->errno,$mysqli->error);
	}else if(mysqli_num_rows($result) > 0)
		$plays = $result->fetch_assoc()["Plays"];


	$statistics = array();
	$statistics['topWinners'] = $topWinners;
	$statistics['topSecond'] = $topSecond;
	$statistics['plays'] = $plays;

	echo json_encode($statistics);

}else{
	echo "Please Login";
}
?>