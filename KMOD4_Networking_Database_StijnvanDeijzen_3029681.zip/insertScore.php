<?php
include 'connect_mysql.php';

if (isset($_GET['PHPSESSID'])) {
	$sid=filter_var($_GET['PHPSESSID'], FILTER_SANITIZE_STRING);
	session_id($sid);
}
session_start();




if(isset($_SESSION["server_id"]) && $_SESSION["server_id"] != 0)
{
	if (isset($_GET['first'])&&isset($_GET['second'])&&isset($_GET['third'])&&isset($_GET['fourth'])) {
		$first=filter_var($_GET['first'], FILTER_SANITIZE_NUMBER_INT);
		$second=filter_var($_GET['second'], FILTER_SANITIZE_NUMBER_INT);
		$third=filter_var($_GET['third'], FILTER_SANITIZE_NUMBER_INT);
		$fourth=filter_var($_GET['fourth'], FILTER_SANITIZE_NUMBER_INT);
	


		$query = "INSERT INTO Scores (id, first_place, second_place, third_place, fourth_place, datetime) VALUES (NULL, $first, $second, $third, $fourth, NULL)";	
		/*database.stijn.online/insertScore.php?first=1&second=2&third=3&fourth=4*/

		if (!($result = $mysqli->query($query))){
		showerror($mysqli->errno,$mysqli->error);
		}else{
			echo "Succesfully inserted score";
		}

	}else{
		echo "Incorrect Data";
	}


}else{
	echo "Please Login";
}

?>