<?php
include 'connect_mysql.php';
session_start();


$email = filter_var($_GET['email'], FILTER_SANITIZE_STRING);
$password = filter_var($_GET['password'], FILTER_SANITIZE_STRING);

$query = "SELECT username FROM Players "
."WHERE email = '$email' "
."AND password = '$password' "
."LIMIT 1";

if (!($result = $mysqli->query($query))){
	showerror($mysqli->errno,$mysqli->error);
}else if(mysqli_num_rows($result) > 0){
	// echo session_id();
	echo $result->fetch_assoc()["username"];
}else{
	echo "Incorrect Login Info";
}


?>